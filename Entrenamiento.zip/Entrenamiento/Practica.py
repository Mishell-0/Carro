import cv2
import os
import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder

def load_images_from_folder(folder, label):
    images = []
    labels = []
    for filename in os.listdir(folder):
        img = cv2.imread(os.path.join(folder, filename))
        if img is not None:
            img = cv2.resize(img, (64, 64))  # Resize for consistency
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            images.append(img)
            labels.append(label)
    return images, labels

def prepare_data():
    green_images, green_labels = load_images_from_folder('Verde', 'green')
    red_images, red_labels = load_images_from_folder('Rojo', 'red')

    X = np.array(green_images + red_images)
    y = np.array(green_labels + red_labels)

    X = X.reshape(len(X), -1)  # Flatten the images

    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(y)

    return X, y, label_encoder

X, y, label_encoder = prepare_data()

model = SVC(kernel='linear')
model.fit(X, y)

def classify_image(image):
    image = cv2.resize(image, (64, 64))
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image = image.reshape(1, -1)
    prediction = model.predict(image)
    return label_encoder.inverse_transform(prediction)[0]

def save_image(folder_name):
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
    ret, frame = cap.read()
    if ret:
        # Encuentra el índice máximo actual en la carpeta
        existing_files = [f for f in os.listdir(folder_name) if f.startswith('image_') and f.endswith('.png')]
        indices = [int(f.split('_')[1].split('.')[0]) for f in existing_files]
        next_index = max(indices, default=0) + 1
        filename = os.path.join(folder_name, f'image_{next_index}.png')
        cv2.imwrite(filename, frame)
        print(f'Saved {filename}')

cap = cv2.VideoCapture(0)

print("Press 'V' to save an image to the Verde folder")
print("Press 'R' to save an image to the Rojo folder")
print("Press 'C' to classify an image")
print("Press 'Esc' to exit")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    cv2.imshow('frame', frame)
    key = cv2.waitKey(1)

    if key == ord('v'):
        save_image('Verde')
    elif key == ord('r'):
        save_image('Rojo')
    elif key == ord('c'):
        color = classify_image(frame)
        if color == 'green':
            print('GO')
        elif color == 'red':
            print('STOP')
    elif key == 27:  # Press Esc to exit
        break

cap.release()
cv2.destroyAllWindows()
