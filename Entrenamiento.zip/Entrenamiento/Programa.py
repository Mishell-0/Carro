import cv2
import numpy as np
import requests
import os
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder

# Dirección IP del ESP32
ESP32_IP = "http://192.168.70.13"

def send_command(command):
    try:
        response = requests.get(f"{ESP32_IP}/{command}")
        if response.status_code == 200:
            return True
        else:
            print(f"Unexpected status code: {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"Error sending command: {e}")
    return False

def load_images_from_folder(folder, label):
    images = []
    labels = []
    for filename in os.listdir(folder):
        img = cv2.imread(os.path.join(folder, filename))
        if img is not None:
            img = cv2.resize(img, (64, 64))  # Resize for consistency
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            images.append(img)
            labels.append(label)
    return images, labels

def prepare_data():
    green_images, green_labels = load_images_from_folder('Verde', 'green')
    red_images, red_labels = load_images_from_folder('Rojo', 'red')

    X = np.array(green_images + red_images)
    y = np.array(green_labels + red_labels)

    X = X.reshape(len(X), -1)  # Flatten the images

    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(y)

    return X, y, label_encoder

X, y, label_encoder = prepare_data()

model = SVC(kernel='linear')
model.fit(X, y)

def classify_image(image):
    image = cv2.resize(image, (64, 64))
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image = image.reshape(1, -1)
    prediction = model.predict(image)
    return label_encoder.inverse_transform(prediction)[0]

# Inicializa la cámara
cap = cv2.VideoCapture(0)

# Variables para controlar el estado de envío de comandos y la impresión del mensaje
sent_red_command = False
sent_green_command = False
no_color_detected_printed = False

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Clasifica la imagen
    color = classify_image(frame)

    # Determina el color predominante y envía el comando
    if color == 'green' and not sent_green_command:
        print("Verde detectado")
        if send_command("GO"):
            print("Comando GO enviado con éxito")
        sent_green_command = True
        sent_red_command = False  # Restablecer el comando rojo
        no_color_detected_printed = False  # Restablecer el estado del mensaje

    elif color == 'red' and not sent_red_command:
        print("Rojo detectado")
        if send_command("STOP"):
            print("Comando STOP enviado con éxito")
        sent_red_command = True
        sent_green_command = False  # Restablecer el comando verde
        no_color_detected_printed = False  # Restablecer el estado del mensaje

    else:
        # Mostrar mensaje solo si no se ha mostrado antes
        if not no_color_detected_printed:
            print("No se detecta rojo ni verde claramente")
            no_color_detected_printed = True

    # Mostrar la imagen para depuración
    cv2.imshow("Frame", frame)

    # Salir del bucle si se presiona la tecla 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
