import cv2
import os

# Configuración de captura de video
cap = cv2.VideoCapture(0)

# Variables de estado
image_count = {'Verde': 0, 'Rojo': 0}

# Función para guardar una imagen
def save_image(folder_name):
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
    ret, frame = cap.read()
    if ret:
        filename = os.path.join(folder_name, f'image_{image_count[folder_name] + 1}.png')
        cv2.imwrite(filename, frame)
        image_count[folder_name] += 1
        print(f'Saved {filename}')

while True:
    ret, frame = cap.read()
    if not ret:
        break

    cv2.imshow('Video', frame)
    key = cv2.waitKey(1) & 0xFF

    # Guardar imagen si se presiona 'v' o 'r'
    if key == ord('v') and image_count['Verde'] < 20:
        save_image('Verde')
    elif key == ord('r') and image_count['Rojo'] < 20:
        save_image('Rojo')
    elif key == 27:  # ESC key
        break

cap.release()
cv2.destroyAllWindows()
